# WIFI-password
It's a small python project to get the WIFI password. It is short and simple. It will give you the password of the available devices around you.
